
package guestbook;

import static org.assertj.core.api.Assertions.*;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Sort;


@SpringBootTest
@Transactional
class GuestbookRepositoryIntegrationTests {

	@Autowired GuestbookRepository repository;

	@Test
	void persistsGuestbookEntry() {

		GuestbookEntry entry = repository.save(new GuestbookEntry("vishnu", "I like you"));

		assertThat(repository.findAll()).contains(entry);
	}

	@Test 
	void findsGuestbookEntryByAuthorName() {

		GuestbookEntry entry = repository.save(new GuestbookEntry("vishnu", "i like you"));

		assertThat(repository.findByName("Yoda", Sort.by("date"))).contains(entry);
	}
}
